namespace AvailabilityCollector.Models;

public class Matrica
{
    public int ID { get; set; }
    public string MesecLeto { get; set; } = "";
    public string MatricaJSON { get; set; } = "";
}
